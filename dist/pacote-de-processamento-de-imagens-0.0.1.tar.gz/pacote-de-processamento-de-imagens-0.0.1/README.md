# Image Processing

Description.
The Package image_processing is used to:
    Processing:
        - Histogram matching
        - Structural similarity
        - Resize image
    Utils:
        - Read Image
        - Save Image 
        - Plot Image
        - Plot Result

## Instalation

Use the package menager [pip](https://pip.pypa.io/en/stable/) to install

## Author
Fabio